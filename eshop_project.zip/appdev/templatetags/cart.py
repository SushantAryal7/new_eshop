from django import template
from ..models import Index

register = template.Library()


@register.filter(name='yes_it_is_selected')
def yes_it_is_selected(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return True
    return False


@register.filter(name='count_of_product')
def count_of_product(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)
    return 0

@register.filter(name='price_of_product')
def price_of_product(product, cart):
    a = int(count_of_product(product, cart))
    b = int(product.price)
    print(8*8)
    print(a)
    print(b)
    return a*b


@register.filter(name='totals')
def totals(products,cart):
    summ = 0
    for p in products:
        summ += price_of_product(p, cart)
    return summ



@register.simple_tag
def symbel():
    return "₹"

@register.filter(name='totalprice')
def totalprice(quantity, price):
    return int(quantity)*int(price)
